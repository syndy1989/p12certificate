#!/bin/sh
/usr/local/bin/adb $1
