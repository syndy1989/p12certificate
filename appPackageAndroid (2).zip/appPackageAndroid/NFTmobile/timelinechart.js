function loadgraph(ClickName)
{
 
                $.getJSON("Result.json", function(json)
    {
                 var ul = document.getElementById(ClickName);

if(ul!=undefined)
{
//alert("uifffff"+ul.childElementCount)
    $("#"+ClickName+ClickName).remove();
 
}
else
{
alert("elseeee")
$("#"+ClickName).remove(); 
/*$("#"+timelineChart).remove();*/
}
                                var hits= json
                                for(var i=0;i< json.length ;i++)
                                {
                                                var eachobj=hits[i];
                                                var eachobjkeys=Object.keys(eachobj);
                                //            var eachusecase=eachobj[eachobjkeys]; 
                                                                                                                 
                                                eachobjkeys.forEach(function (key)
                                                {
                                                                if(eachobj.hasOwnProperty(usecasenamedtl))
                                                                {                          
                                                                                var eachusecase=eachobj[eachobjkeys];    

                                                                                for(var j=0;j<eachusecase.length;j++)
                                                                                {
                                                                                                var eachPage = eachusecase[j];
                                                                                                var eachpagekeys=Object.keys(eachPage);
                                                                                                if(eachpagekeys==ClickName)
                                                                                                {
                                                                                                    
                                                                                                   // alert(ClickName+"=="+eachpagekeys)
                                                                                                                var pagewisedetails=eachPage[eachpagekeys];
                                                                                                                var RequestedPageArr=[];
                                                                                                                var StrTimeArr=[];
                                                                                                                var EndTimeArr=[];
                                                                                                                var role=[];
                                                                                                                
                                                                                                                var chartDiv1 = document.createElement('div');
                                                                                                                chartDiv1.setAttribute("class","row");
                                                                                                                 chartDiv1.setAttribute("id",ClickName+ClickName);
                                                                                                                var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('a');
                        heading3.setAttribute("class","panel-title");                        
                       
                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML=eachpagekeys;
                                                                  

                        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");                                              
                         var chartDiv = document.createElement('div');
                        chartDiv.setAttribute("class","col-lg-12");
                                                                                                               chartDiv.setAttribute("id","timelineChart");                                    
                                                                                                                google.charts.load('current', {'packages':['timeline']});
                                                                                                                google.charts.setOnLoadCallback(drawChart);
                                                                                                                var size = pagewisedetails.NetworkDetails.length;
                                                                                                                var hig = (100*size);
                                                                                                                chartDiv.setAttribute("style", "height: "+hig+"px;");
                                                                                                                var n = 0;
                                                                                                                for(var m=0; m<(pagewisedetails.NetworkDetails.length); m++)
                                                                                                                {
                                                                                                //                            alert("naa vandhitenn"+ClickName)     
                                                                                                                                var networkdetails = pagewisedetails.NetworkDetails[m];
                                                                                                                                var strTime =      networkdetails.Time.start ;
                                                                                                                                                
                                                                                                                                strTime = strTime.replace(/([-:.T])/gi, ',');
                                                                                                //                            alert("strTime is "+strTime);
                                                                                                //                            var EndTime =   networkdetails.Time.end ;
                                                                                                //                            EndTime = EndTime.replace(/([-:.T])/gi, ',');
                                                                                                                                strTime=strTime.slice(0, -6);
                                                                                                //                            EndTime=EndTime.slice(0, -6);
                                                                                                                                var caseWiseStrtTime = strTime ;
                                                                                                                                                
                                                                                                                                var strtTmSplt = strTime.split(",");
                                                                                                                                var sec = parseInt(strtTmSplt[6]);
                                                                                                                                var min = parseInt(strtTmSplt[5]);
                                                                                                                                                
                                                                                                                                                
                                                                                                                                var q=0;
                                                                                                                                                
                                                                                                                                var caseWiseEndTime ="";
                                                                                                                                for(var p=n;p<(n+4);p++)
                                                                                                                                {
                                                                                //                                                            alert("loop no "+ q)
                                                                                                                                                                
                                                                                                                                                if(q==0)
                                                                                                                                                {
                                                                                                                                                                
                                                                                                                                                                sec= sec+ networkdetails.Duration.connect ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {              
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "connect" ;
                                                                                                //                                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                }
                                                                                                                                                if(q==1)
                                                                                                                                                {
                                                                                                                                                                sec= sec+ networkdetails.Duration.dns ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "dns" ;
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                }
                                                                                                                                                if(q==2)
                                                                                                                                                {                                                                              
                                                                                                                                                                sec= sec+ networkdetails.Duration.ssl ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "ssl" ;
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                                
                                                                                                                                                }
                                                                                                                                                if(q==3)
                                                                                                                                                {
                                                                                                                                                                sec= sec+ networkdetails.Duration.latency ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "latency" ;
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                                
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                caseWiseStrtTime = caseWiseEndTime;
                                                                                                                
                                                                                                                                                q++;
                                                                                                                                                RequestedPageArr[p] = networkdetails.RequestedPage+"_"+n ;
                                                                                                                                                                
                                                                                                                                }
                                                                                                                                n = n +4;
                                                                                                                
                                                                                                                                
                                                                                                                                
                                                                                                //                            StrTimeArr[m] = strTime ;
                                                                                                //            EndTimeArr[m] = EndTime
                                                                                                //            alert("value " +m+"  - " + RequestedPageArr[m]+"  "+ StrTimeArr[m] +"  "+EndTimeArr[m]);
                                                                                                                }
                                                                                                
                                                                                                                /* <!-- drawChart(RequestedPageArr ,StrTimeArr, EndTimeArr); -->*/
                                                                                                                
                                                                                                function drawChart() {                                                   
                                                                                                                var container = document.getElementById('timelineChart');
                                                                                                                var TLchart = new google.visualization.Timeline(container);
                                                                                                                var dataTable = new google.visualization.DataTable();
                                                                                                
                                                                                                                dataTable.addColumn({ type: 'string', id: 'President' });
                                                                                                                dataTable.addColumn({ type: 'string', id: 'roles' });
                                                                                                                dataTable.addColumn({ type: 'date', id: 'Start' });
                                                                                                                dataTable.addColumn({ type: 'date', id: 'End' }); 
                                                                //                                            alert("size is" +size)
                                                                                                                for(var j=0; j<(size*4); j++)
                                                                                                                {
                                                                //          alert("StrTime is  " +StrTimeArr[j] +"   ; EndTime  is " + EndTimeArr[j]);
                                                                /*                          var networkdetails = pagewisedetails[j];
                                                                                                                                var RequestedPage = networkdetails.RequestedPage ;
                                                                                                                                var StrTime = networkdetails.StrtTime ;
                                                                                                                                var EndTime = networkdetails.EndTime ;  */
                                                                                                                                
                                                                                                                                var str1 = StrTimeArr[j].split(",");
                                                                                                                                var str2 = EndTimeArr[j].split(",");
                                                                                                                                
                                                                                                                                                                
                                                                                                                                dataTable.addRow(
                                                                                                                                                [ RequestedPageArr[j],role[j], new Date(str1[0],str1[1],str1[2],str1[3],str1[4],str1[5],str1[6]), new Date(str2[0],str2[1],str2[2],str2[3],str2[4],str2[5],str2[6]) ]);
                                                                                                                }
                                                                                                                                
                                                                                                                                TLchart.draw(dataTable);                                                                               
                                                                                                }        
                                                                                                panelHeading.appendChild(heading3);
                                                                                                panelBody.appendChild(chartDiv)

                                                                                                panelRoot.appendChild(panelHeading);
                                                                                                panelRoot.appendChild(panelBody)
                                                                                                gridWidth.appendChild(panelRoot);          
                                                                                                chartDiv1.appendChild(gridWidth);
                                                                                                                
                                                                                                document.getElementById(eachpagekeys).appendChild(chartDiv1); 
                                                                                                
                                                                                                }
                                                                                                
                                                                                

                                                                                }
                                                                }
                                                })
                                                
        }
          
    });
}
