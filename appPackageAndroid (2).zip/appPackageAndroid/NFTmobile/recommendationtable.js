function loadrecommendations(ClickName)
{
$.getJSON("Result.json", function(json) 
{

	  var ul = document.getElementById(ClickName);

if(ul!=undefined)
$("#"+ClickName+ClickName).remove();
	//document.getElementById(eachpagekeys).appendChild(row);      
    var mainObj=json;

   for(var i=0;i<json.length;i++)
            {      
                        //var usecasename=usecasenamedtl;
                       var eachobj=mainObj[i];
                        var eachobjkeys=Object.keys(eachobj);
                        eachobjkeys.forEach(function (key)
                         {
                        if(eachobj.hasOwnProperty(usecasenamedtl))
                        {                          
                       var eachusecase=eachobj[eachobjkeys];    

                     for(var j=0;j<eachusecase.length;j++)
                     {
                        var eachpage=eachusecase[j];
                        var eachpagekeys=Object.keys(eachpage);
                         if(eachpagekeys==ClickName)
                     {
                        var pagewisedetails=eachpage[eachpagekeys];
                               
                        var row=document.createElement('div');
                        row.setAttribute("class","row");
                         row.setAttribute("id",ClickName+ClickName);

                        var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('h3');
                        heading3.setAttribute("class","panel-title");

                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML=eachpagekeys;
                     //alert(eachpagekeys);

                        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");
                        panelBody.setAttribute("class","table-responsive");

                        var heading5=document.createElement('h5');
                        heading5.innerHTML="Network calls count for this page is  ";

                        var table = document.createElement('table');
                                table.setAttribute("class","table table-bordered table-hover table-striped");
                                table.setAttribute("id","table");

                                var tablebody=document.createElement('tbody');
                                tablebody.setAttribute("id",eachpagekeys);

                                var tableheader=document.createElement('thead');
                                var tableheadrow=document.createElement('tr');
                                  var tableheader0=document.createElement('th');
                                  var tableheader1=document.createElement('th');  
                                  var tableheader2=document.createElement('th');                  
                                  

                                  tableheader0.innerHTML="ruleHeader";
                                  tableheader1.innerHTML="Message";
                                   tableheader2.innerHTML="Recommendation";
                    

                                  tableheadrow.appendChild(tableheader0);
                                  tableheadrow.appendChild(tableheader1);
                                  tableheadrow.appendChild(tableheader2);
                                 
                                  tableheader.appendChild(tableheadrow)

                                  var recommendations;
                           		   var netcalls=pagewisedetails.Recommendation.length;      
                    
                              
                    for(k=0;k<netcalls;k++)
                    {
                      var recommendkeys;
                      var recommendvalues;  
                      recommendations=pagewisedetails.Recommendation[k];
                      recommendkeys=Object.keys(recommendations);
                      var messages=[];
                      messages=recommendations.Message;
                      var urls=[];                    
                       urls=messages.split(',');
                       var  message=urls.join("<br>")
                      /* var nextpart=messages[1];
                       
                       if(nextpart!=undefined)
                       {                     
                        urls=nextpart.split(',');
                        var eachurl;
                       // alert(urls.length)
                        for(var i=0;i<urls.length;i++)
                        {
                          //alert(urls[i]);
                          nextpart=urls.join("<br>")
                       // }
                        
                      }
                     else
                     {
                      nextpart="";
                     }*/
                      var message  =message;
                      var tablerow=document.createElement('tr');                        
                      var tablecolum0=document.createElement('td');
                      var tablecolum1=document.createElement('td');   
                      var tablecolum2=document.createElement('td');  
                 
                      tablecolum0.innerHTML=recommendations.ruleHeader;
                      tablecolum1.innerHTML=message;
                      tablecolum2.innerHTML=recommendations.Recommendation;
                      tablerow.appendChild(tablecolum0); 
                      tablerow.appendChild(tablecolum1); 
                      tablerow.appendChild(tablecolum2); 
 
                      tablebody.appendChild(tablerow);
              }
            
             
               table.appendChild(tableheader);
               table.appendChild(tablebody);
               panelHeading.appendChild(heading3);                    

        		panelRoot.appendChild(panelHeading);
       			panelRoot.appendChild(panelBody);
        		panelBody.appendChild(table);
         		
        		//panelRoot.appendChild(heading5);
       			gridWidth.appendChild(panelRoot);
       			
        		row.appendChild(gridWidth);
        		document.getElementById(eachpagekeys).appendChild(row);       
   					 } 
  			      }    
              }                 
              });
 	       }          

});	
}